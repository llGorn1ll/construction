    <div class="pagers2">
        <?php if (!isset($_SESSION['users']['id'])) { ?>
            <div class="logRegDiv">
                <a class="logAndRegElements" href="reg.php">Регистрация</a>
            </div>
        <?php } ?> 